<?php
class Database
{
    var $host = "127.0.0.1";
    var $username = "root";
    var $password = "";
    var $database = "mawapres";
    var $connection = "";
}
